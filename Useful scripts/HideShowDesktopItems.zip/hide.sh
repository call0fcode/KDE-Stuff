#!/bin/bash

for i in ~/Escritorio/*; do echo "$i"; done | cut -d "/" -f 5 > ~/Escritorio/.hidden