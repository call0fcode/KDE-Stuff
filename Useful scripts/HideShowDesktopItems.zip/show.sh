#!/bin/bash

rm ~/Escritorio/.hidden