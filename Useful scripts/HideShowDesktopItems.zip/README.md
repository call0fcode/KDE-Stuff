# Two simple scripts to hide / show the items on your KDE desktop

This two scripts are useful to quickly **hide / show all items on your desktop** by clicking on it on your file explorer.

This is specially useful on KDE Plasma where there's no direct option on the desktop's context menu to do this.

It is even better to move the scripts to the folder /bin in order they to be available across the whole system and adding a KDE shortcut for each of them into "System Settings".

Of course you can replace the path ```~/Escritorio/``` (*Escritorio* means Desktop in Spanish) with the one you wish! =)