# KDE Dolphin tweaks

Paste the files on `~/.local/share/kservices5/ServiceMenus/`, restart Dolphin and you should see the options in the context menu.

If they still not appear in Dolphin go to "Settings -> Configure Dolphin...-> Services" and activate the services you want.
They should be there. If not, close Dolphin or even log out and in on your session.